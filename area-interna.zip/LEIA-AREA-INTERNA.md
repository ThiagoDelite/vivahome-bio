# Área interna Vivá Home (www.vivahome.com.br/interno)

## Arquivos para subir no GitHub (repositório vivahome-bio)
- interno.html
- interno.webmanifest
- icone-180.png e icone-512.png
- produtos.html (menu com o link "Área interna")
- pasta api/ com o arquivo ler-etiqueta.js (mantenha a pasta: api/ler-etiqueta.js)

NÃO suba o arquivo supabase-configuracao.sql (ele é só para o passo 1).

## 1. Supabase (banco, login e fotos), gratuito
1. Crie uma conta em supabase.com e um projeto novo (região São Paulo).
2. SQL Editor > New query > cole o conteúdo de supabase-configuracao.sql > Run.
3. Authentication > Users > Add user > Create new user:
   - Email: rafael.galindo@vivahome.com.br   (o login "Rafael Galindo" vira esse email)
   - Senha: a que você definir (não escreva a senha em nenhum arquivo)
   - Marque "Auto Confirm User".
4. Authentication > Sign In / Providers: desligue "Allow new users to sign up" (só você cria usuários).
5. Project Settings > API: copie "Project URL" e a chave "anon public".

## 2. interno.html
No topo do arquivo, troque COLE_AQUI_A_PROJECT_URL e COLE_AQUI_A_ANON_KEY pelos valores copiados.

## 3. Leitura automática da etiqueta (Google Gemini)
1. Entre em aistudio.google.com com uma conta Google > "Get API key" > "Create API key".
2. Vercel > projeto vivahome-bio > Settings > Environment Variables, adicione:
   - GEMINI_API_KEY = a chave criada
   - SUPABASE_URL = Project URL do Supabase
   - SUPABASE_ANON_KEY = chave anon public
3. Deployments > ... > Redeploy.
Sem esse passo a área funciona, mas os campos são preenchidos à mão.
(Alternativa: em vez de GEMINI_API_KEY, use ANTHROPIC_API_KEY com uma chave do console.anthropic.com.)

## 4. Atalho no iPhone do Rafael
Safari > www.vivahome.com.br/interno > botão Compartilhar > "Adicionar à Tela de Início".
O ícone preto com o monograma abre direto a área interna, já logada.
