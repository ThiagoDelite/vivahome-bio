-- ============================================================
-- Vivá Home | Área interna (estoque)
-- Cole tudo no Supabase: SQL Editor > New query > Run
-- ============================================================

-- 1) Tabela do estoque
create table if not exists public.estoque (
  id             uuid primary key default gen_random_uuid(),
  nome           text default '',
  codigo         text default '',
  marca          text default '',
  medidas        text default '',
  preco          text default '',
  grupo          text default 'Decor',
  tipo           text default '',
  quantidade     integer not null default 1 check (quantidade >= 0),
  obs            text default '',
  texto_etiqueta text default '',
  foto_etiqueta  text default '',
  foto_produto   text default '',
  criado_por     uuid default auth.uid() references auth.users(id),
  criado_em      timestamptz not null default now(),
  atualizado_em  timestamptz not null default now()
);

-- 2) Só quem está logado lê e escreve (ninguém de fora vê nada)
alter table public.estoque enable row level security;

drop policy if exists "estoque_logados" on public.estoque;
create policy "estoque_logados" on public.estoque
  for all to authenticated
  using (true) with check (true);

-- 3) Pasta privada para as fotos
insert into storage.buckets (id, name, public)
values ('fotos', 'fotos', false)
on conflict (id) do nothing;

drop policy if exists "fotos_ler"     on storage.objects;
drop policy if exists "fotos_enviar"  on storage.objects;
drop policy if exists "fotos_apagar"  on storage.objects;
create policy "fotos_ler"    on storage.objects for select to authenticated using (bucket_id = 'fotos');
create policy "fotos_enviar" on storage.objects for insert to authenticated with check (bucket_id = 'fotos');
create policy "fotos_apagar" on storage.objects for delete to authenticated using (bucket_id = 'fotos');
